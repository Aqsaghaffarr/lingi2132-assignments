// UnaryAddition.java

package pass;

public class UnaryAddition
{
	public int unaryAdd(int x)
	{
		return +x;
	}
}