// Remainder.java

package pass;

public class Remainder
{
	public int takeRemainder(int x, int y)
	{
		return x % y;
	}
}