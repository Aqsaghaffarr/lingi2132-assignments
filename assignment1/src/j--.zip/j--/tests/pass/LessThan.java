// LessThan.java

package pass;

public class LessThan
{
	public boolean lessThan(int x, int y)
	{
		return x < y;
	}
}