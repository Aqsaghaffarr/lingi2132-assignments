// UnaryAddition.java

package fail;

import java.lang.System;

public class UnaryAddition
{
	public static void main(String[] args)
	{
		System.out.println(+('a'));
	}
}