// LessThan.java

package fail;

import java.lang.System;

public class LessThan
{
	public static void main(String[] args)
	{
		System.out.println('a' < 5);
	}
}