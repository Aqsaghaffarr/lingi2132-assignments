package pass;

import java.lang.System;

public class MultilineComment {

    public static void comment() {
        /*
         * This is a comment which should not break compilation!
         */
    }

}
