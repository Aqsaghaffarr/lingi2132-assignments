package pass;

public class Or {

    public static boolean or(boolean a, boolean b) {
        return a || b;
    }

}
