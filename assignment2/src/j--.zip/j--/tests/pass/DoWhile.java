package pass;

public class DoWhile {

    public static int dowhile(int a) {
        do {
        	a = a - 1;
        } while (a > 0);
        return a;
    }

}
