package fail;

import java.lang.System;

public class DoWhileErrors {

    public static void main(String[] args) {
        do {
        	i = 0
        } while ("not a boolean")
    }

}
